#!/bin/bash

#AYUDA Si el primer parametro es -help se muestra la explicacion de la sintaxis.
if [ "$1" = "-help" ]; then
    	echo " "
	echo "-MENU DE AYUDA-"
	echo " "
	echo "SINTAXIS PARA EL SCRIPT: $0 /ruta/origen /ruta/destino"
    	echo "ORIGEN: que backupeamos ; DESTINO: donde lo guardamos"
	echo ""
   	exit 0
fi

#VALIDAR ARGUMENTOS Si la cantidad de argumentos es distinto de 2.
if [ "$#" -ne 2 ]; then
    	echo " "
	echo "Error: Se requieren 2 argumentos."
    	echo "Usar $0 -help si necesitas ayuda."
    	echo " "
	exit 1
fi

#ASIGNAR ARGUMENTOS
ORIGEN=$1 #Guardo el primer argumento como el origen.
DESTINO_BASE=$2 #Gurado el segundo argumento como el destino del backup.

#VALIDAR DIRECTORIOS me fijo si los directorios pasados existan antes de hacer el backup.
if [ ! -d "$ORIGEN" ]; then  #Si no existe el directorio en origen.
    	echo " "
	echo "ERROR. Directorio origen: '$ORIGEN' no fue encontrado." 
    	echo " "
	exit 1
fi

if [ ! -d "$DESTINO_BASE" ]; then #Si no existe el directorio donde queremos guardar el backup.
    	echo " "
	echo "ERROR. Directorio destino: '$DESTINO_BASE' no fue encontrado."
    	echo " "
	exit 1
fi

#PREPARAR ARGUMENTOS
FECHA=$(date +%Y%m%d) #Gurado en la variable fecha el formato date como YYMMDD.
NOMBRE_BASE=${ORIGEN##*/} #Borro las carpetas anteriores hasta */ con el comando ##
DESTINO_FINAL="${DESTINO_BASE}/${NOMBRE_BASE}_bkp_${FECHA}.tar.gz" 
#Conecto las variables para crear la ruta completa para poder hacer el backup.
#Junto los dos parametros , el primero y el final modificado para cumplir con los requisitos del TP

#EJECUTAR BACKUP
echo "..."
echo "CREANDO BACKUP...."
echo "..."
tar -czf "$DESTINO_FINAL" "$ORIGEN" #Con tar empaqueto ambos parametros.
echo "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
echo "Backup listo en $DESTINO_FINAL" #Muestro el mensaje que termino el backup.
echo "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
exit 0 #Termino el scrip.
